## Contributing
Contributing to Project Forecaster is very simple:
1. Fork it on GitHub
2. Add your contribution code
3. Run `npm run build`
4. Submit a pull-request

Thanks!
